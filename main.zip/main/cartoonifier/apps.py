from django.apps import AppConfig


class CartoonifierConfig(AppConfig):
    name = 'cartoonifier'
