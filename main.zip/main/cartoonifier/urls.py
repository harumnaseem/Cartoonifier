from django.urls import path
from . import views

urlpatterns = [
    path('cartoon/', views.cartoon),
    #Add a new route below this
    path('bw/', views.bw),
]